/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj_gestion_facture;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JFrame;
import org.ifri.nathalie.view.Fenetre_produit;
import org.ifri.nathalie.view.MENU;
import org.ifri.nathalie.view.fenetre;

/**
 *
 * @author gracia
 */
public class Proj_gestion_facture {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("la vie  est belle");
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Proj_gestion_facturePU");
        EntityManager em = emf.createEntityManager();
        //JFrame fenetre = new fenetre();
        //fenetre.setTitle("TOLODE");
       // fenetre.setVisible(true);
       
       JFrame fenetre = new MENU();
       fenetre.setTitle("TOLODE");
       fenetre.setVisible(true);
    }
    
}
