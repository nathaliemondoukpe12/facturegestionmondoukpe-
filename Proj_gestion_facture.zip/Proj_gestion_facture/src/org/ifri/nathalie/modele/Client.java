/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.ifri.nathalie.modele;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gracia
 */
@Entity
public class Client {
    
    @Id
    @GeneratedValue (strategy=GenerationType.AUTO)
    private Integer numclient;
    private String nomclient;
    private String prenomclient;
    private Integer telclient;
    @Temporal(TemporalType.DATE)
    private Date datenaissance;
    
    
    private String supp = "non";
     public Client(){
         
     }

    public Client(int numclient, String nomclient,String prenomclient,Date datenaissance ,int telclient){
    this.numclient= numclient;
    this.nomclient=nomclient;
    this.prenomclient=prenomclient;
    this.telclient=telclient;
    this.datenaissance=datenaissance;
    }

    public String getSupp() {
        return supp;
    }

    public void setSupp(String supp) {
        this.supp = supp;
    }

    public int getNumclient() {
        return numclient;
    }

    public void setNumclient(int numclient) {
        this.numclient = numclient;
    }

    public String getNomclient() {
        return nomclient;
    }

    public void setNomclient(String nomclient) {
        this.nomclient = nomclient;
    }

    public String getPrenomclient() {
        return prenomclient;
    }

    public void setPrenomclient(String prenomclient) {
        this.prenomclient = prenomclient;
    }

    public Integer getTelclient() {
        return telclient;
    }

    public void setTelclient(Integer telclient) {
        this.telclient = telclient;
    }

    public Date getDatenaissance() {
        return datenaissance;
    }

    public void setDatenaissance(Date datenaissance) {
        this.datenaissance = datenaissance;
    }
    
}
 
    