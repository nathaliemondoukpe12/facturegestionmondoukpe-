/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.ifri.nathalie.modele;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;

/**
 *
 * @author gracia
 */

@Entity
@IdClass(FacturerPK.class)
public class Facturer {
    
    @Id
    @ManyToOne
     private Facture facture;
    @Id
    @ManyToOne
    private Produit produit;
    private Integer quantite;

    public Facturer() {
    }

    public Facturer(Integer quantite, Facture facture, Produit produit) {
        this.quantite = quantite;
        this.facture = facture;
        this.produit = produit;
    }

    public Integer getQuantite() {
        return quantite;
    }

    public void setQuantite(Integer quantite) {
        this.quantite = quantite;
    }

    public Facture getFacture() {
        return facture;
    }

    public void setFacture(Facture facture) {
        this.facture = facture;
    }

    public Produit getProduit() {
        return produit;
    }

    public void setProduit(Produit produit) {
        this.produit = produit;
    }
       
}
