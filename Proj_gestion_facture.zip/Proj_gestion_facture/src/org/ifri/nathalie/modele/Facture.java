/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.ifri.nathalie.modele;

import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author gracia
 */
@Entity
public class Facture {
    @Id
    private int numfacture;
    @Temporal(TemporalType.DATE)
    private Date datefacture;
    //private Produit produit;
    @ManyToOne
    private Client client;
    @OneToMany(mappedBy = "facture")
    private List<Facturer> facturers;

    public Facture() {
    }

    
    public Facture(int numfacture, Date datefacture, Client client) {
        this.numfacture = numfacture;
        this.datefacture = datefacture;
        this.client = client;
    }
     @Override
    public String toString() {
        return "Facture{" + "numfact=" + numfacture + ", datefact=" + datefacture + ", client=" + client + '}';
}

    public int getNumfacture() {
        return numfacture;
    }

    public void setNumfacture(int numfacture) {
        this.numfacture = numfacture;
    }

    public Date getDatefacture() {
        return datefacture;
    }

    public void setDatefacture(Date datefacture) {
        this.datefacture = datefacture;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
    
    }
