/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.ifri.nathalie.modele;

import javax.persistence.Id;

/**
 *
 * @author gracia
 */
public class FacturerPK {
    @Id
    private int facture;
    @Id
    private int produit;

    public FacturerPK() {
    }

    public FacturerPK(int facture, int produit) {
        this.facture = facture;
        this.produit = produit;
    }

    public int getFacture() {
        return facture;
    }

    public void setFacture(int facture) {
        this.facture = facture;
    }

    public int getProduit() {
        return produit;
    }

    public void setProduit(int produit) {
        this.produit = produit;
    }

    
    
    
}
