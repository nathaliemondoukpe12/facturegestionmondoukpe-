/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.ifri.nathalie.modele;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author gracia
 */

@Entity
public class Produit {
    @Id
    @GeneratedValue (strategy=GenerationType.AUTO)
     private Integer refprod;
     private String designation;
     private Integer pu;
     private String supp = "non";
   @OneToMany(mappedBy = "produit")
    private List<Facturer> facturers;
     public Produit(){
         
     }
     
    

    public Produit(Integer refprod, String designation, Integer pu) {
        this.refprod = refprod;
        this.designation = designation;
        this.pu = pu;
    }

    public int getRefprod() {
        return refprod;
    }

    public void setRefprod(Integer refprod) {
        this.refprod = refprod;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Integer getPu() {
        return pu;
    }

    public void setPu(Integer pu) {
        this.pu = pu;
    }

    public String getSupp() {
        return supp;
    }

    public void setSupp(String supp) {
        this.supp = supp;
    }

    
}
